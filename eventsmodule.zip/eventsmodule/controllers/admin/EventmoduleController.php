<?php
/**
* 2007-2020 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2020 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

class EventmoduleController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function init()
    {
        parent::init();
        $this->bootstrap = true;
    }

    public function initContent()
    {
        parent::initContent();
        $this->context->smarty->assign(array());
        $this->setTemplate('addevent.tpl');
    }

    public function initProcess()
    {
        // gets POST data
        if (Tools::isSubmit('eventsubmit')) {
            // gets input field value from configuration.tpl
            $tablename = 'events';
            $eventname = Tools::getValue('heading');
            $date = Tools::getValue('date');
            $date .= ' '. Tools::getValue('time');
            $content = Tools::getValue('content');

            $this->uploadImage();
            //insert data to table
            Db::getInstance()->insert($tablename, array(
                'name' => pSQL($eventname),
                'date' => pSQL($date),
                'image_ref' => pSQL($_FILES['file_image']['name']),
                'content' => pSQL($content, true)
            ));
        }
    }

    // uploads image to designated folder
    public function uploadImage()
    {
        $uploaddir = 'C:\xampp\htdocs\prestashop_1.7.6.5\prestashop\modules\eventsmodule\views\img\\';
        // generate new name for a file based on UNIX time
        $temp = explode(".", $_FILES["file_image"]["name"]);
        $newfilename = round(microtime(true)) . '.' . end($temp);
        if ($_FILES['file_image']['name']) {
            $_FILES['file_image']['name'] = $newfilename;
        }
        
        // destination to save the file
        $uploadfile = $uploaddir . basename($newfilename);

        // get feedback if image upload was successful
        if (move_uploaded_file($_FILES['file_image']['tmp_name'], $uploadfile)) {
            $this->context->smarty->assign(array(
                'UPLOAD_STATUS' => '* Üritus lisatud'
            ));
        } else {
            $this->context->smarty->assign(array(
                'UPLOAD_STATUS' => 'Midagi läks valesti'
            ));
        }
    }
}
